import React from 'react';
import './Forum.css';

function Sidebar({ onSelectTopic }) {
  const topics = ['Food', 'Games', 'IPL', 'India vs Pakistan', 'News', 'Technology', 'Education'];

  return (
    <div className="sidebar">
      <h3>Topics</h3>
      <ul>
        {topics.map((topic) => (
          <li key={topic} onClick={() => onSelectTopic(topic)}>
            {topic}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Sidebar;
