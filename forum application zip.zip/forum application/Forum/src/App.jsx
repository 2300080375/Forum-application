import { useState, useEffect } from 'react';
import './Forum.css';
import Auth from './Auth';

function App() {
  const [user, setUser] = useState(null);
  const [posts, setPosts] = useState(() => {
    const savedPosts = localStorage.getItem('forumPosts');
    const parsedPosts = savedPosts ? JSON.parse(savedPosts) : [];
    return parsedPosts.map(post => ({
      ...post,
      comments: Array.isArray(post.comments)
        ? post.comments.map(comment => ({
            ...comment,
            isNew: false,
          }))
        : [],
    }));
  });
  const [newPost, setNewPost] = useState('');
  const [newPostTopic, setNewPostTopic] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState(null);
  const [newComment, setNewComment] = useState({});

  useEffect(() => {
    localStorage.setItem('forumPosts', JSON.stringify(posts));
  }, [posts]);

  const handleLogin = (userData) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
    setSelectedTopic(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newPost.trim() && newPostTopic) {
      const newPostData = {
        id: posts.length + 1,
        title: newPost,
        content: 'Sample content',
        author: user.username,
        topic: newPostTopic,
        timestamp: new Date().toISOString(),
        comments: [],
      };
      setPosts([newPostData, ...posts]);
      setNewPost('');
      setNewPostTopic('');
      setShowForm(false);
    }
  };

  const handleCommentSubmit = (postId) => (e) => {
    e.preventDefault();
    const commentText = newComment[postId] || '';
    if (commentText.trim()) {
      try {
        const updatedPosts = posts.map(post => {
          if (post.id === postId) {
            const currentComments = Array.isArray(post.comments) ? post.comments : [];
            return {
              ...post,
              comments: [
                ...currentComments,
                {
                  id: currentComments.length + 1,
                  text: commentText,
                  author: user.username,
                  timestamp: new Date().toISOString(),
                  isNew: true,
                },
              ],
            };
          }
          return post;
        });
        setPosts(updatedPosts);
        setNewComment(prev => ({ ...prev, [postId]: '' }));
      } catch (error) {
        console.error('Error submitting comment:', error);
      }
    }
  };

  const handleDeleteComment = (postId, commentId) => () => {
    try {
      const updatedPosts = posts.map(post => {
        if (post.id === postId) {
          const updatedComments = post.comments.filter(comment => comment.id !== commentId);
          return {
            ...post,
            comments: updatedComments,
          };
        }
        return post;
      });
      setPosts(updatedPosts);
    } catch (error) {
      console.error('Error deleting comment:', error);
    }
  };

  const handleClearComment = (postId) => () => {
    setNewComment(prev => ({ ...prev, [postId]: '' }));
  };

  const discussionTopics = [
    'IPL',
    'Ind vs Pak',
    'Stocks',
    'Trending Songs',
    'Movies',
    'Tech News',
    'Fashion',
    'Gaming',
    'Fitness',
    'Food & Recipes',
  ];

  const getPostsForTopic = (topic) => {
    return posts
      .filter(post => post.topic === topic)
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  };

  const filteredPosts = selectedTopic
    ? posts.filter(post => post.topic === selectedTopic)
    : posts;

  if (!user) {
    return (
      <div className="forum-container">
        <Auth onLogin={handleLogin} />
      </div>
    );
  }

  return (
    <div className="app-wrapper">
      <button className="sidebar-toggle" onClick={() => setShowSidebar(!showSidebar)}>
        {showSidebar ? '✕' : '☰'}
      </button>

      <div className={`sidebar ${showSidebar ? 'visible' : ''}`}>
        <h2 className="sidebar-title">Top Discussion</h2>
        <ul className="discussion-list">
          {discussionTopics.map((topic, index) => {
            const topicPosts = getPostsForTopic(topic);
            return (
              <li key={index} className="discussion-item">
                <button
                  className={`discussion-button ${selectedTopic === topic ? 'active' : ''}`}
                  onClick={() => setSelectedTopic(topic)}
                >
                  {topic} <span className="post-count">({topicPosts.length})</span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      <div className={`forum-container ${showSidebar ? 'shifted' : ''}`}>
        <div className="auth-button-container">
          <span className="welcome-text">Welcome, {user.username}!</span>
          <button onClick={handleLogout} className="auth-button">Logout</button>
        </div>
        <header className="forum-header">
          <h1>Forum App</h1>
          <p>Join the discussion and share your thoughts!</p>
        </header>
        <div className="forum-actions">
          <button className="action-button" onClick={() => setShowForm(!showForm)}>
            {showForm ? 'Cancel' : 'New Post'}
          </button>
          {selectedTopic && (
            <button
              className="action-button clear-filter"
              onClick={() => setSelectedTopic(null)}
            >
              Show All Posts
            </button>
          )}
        </div>
        {showForm && (
          <form onSubmit={handleSubmit} className="forum-actions">
            <input
              type="text"
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              placeholder="Write a post title..."
              autoFocus
            />
            <select
              value={newPostTopic}
              onChange={(e) => setNewPostTopic(e.target.value)}
              required
            >
              <option value="" disabled>Select a topic...</option>
              {discussionTopics.map((topic, index) => (
                <option key={index} value={topic}>{topic}</option>
              ))}
            </select>
            <button type="submit" className="action-button">Post</button>
          </form>
        )}
        <div className="forum-feed">
          <h2>{selectedTopic ? `${selectedTopic} Threads` : 'Recent Threads'}</h2>
          {filteredPosts.length > 0 ? (
            <ul className="thread-list">
              {filteredPosts.map((post) => (
                <li key={post.id} className="thread-item">
                  <h3>{post.title}</h3>
                  <p>{post.content}</p>
                  <p className="thread-topic">Topic: {post.topic || 'General'}</p>
                  <p className="thread-author">Posted by: {post.author}</p>
                  <p className="thread-timestamp">Posted on: {new Date(post.timestamp).toLocaleString()}</p>
                  <div className="comments-section">
                    <h4>Comments ({post.comments ? post.comments.length : 0})</h4>
                    {post.comments && post.comments.length > 0 ? (
                      <ul className="comment-list">
                        {post.comments.map(comment => (
                          <li
                            key={comment.id}
                            className={`comment-item ${comment.isNew ? 'new-comment' : ''}`}
                          >
                            <div className="comment-content">
                              <p>{comment.text} - {comment.author}</p>
                              {comment.author === user.username && (
                                <button
                                  className="delete-button"
                                  onClick={handleDeleteComment(post.id, comment.id)}
                                >
                                  Delete
                                </button>
                              )}
                            </div>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p>No comments yet. Be the first to comment!</p>
                    )}
                    <form onSubmit={handleCommentSubmit(post.id)} className="comment-form">
                      <div className="comment-input-wrapper">
                        <input
                          type="text"
                          value={newComment[post.id] || ''}
                          onChange={(e) => setNewComment(prev => ({ ...prev, [post.id]: e.target.value }))}
                          onKeyPress={(e) => {
                            if (e.key === 'Enter' && (newComment[post.id] || '').trim()) {
                              handleCommentSubmit(post.id)(e);
                            }
                          }}
                          placeholder="Add a comment..."
                        />
                        {(newComment[post.id] || '').length > 0 && (
                          <button
                            type="button"
                            className="clear-button"
                            onClick={handleClearComment(post.id)}
                          >
                            ✕
                          </button>
                        )}
                      </div>
                      <button
                        type="submit"
                        className="action-button send-button"
                        disabled={!(newComment[post.id] || '').trim()}
                      >
                        Send
                      </button>
                    </form>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p>No posts found for this topic.</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;