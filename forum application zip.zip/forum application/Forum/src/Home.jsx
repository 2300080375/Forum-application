import React from "react";
import "./Forum.css";

const Home = () => {
  return (
    <div className="forum-container">
      <header className="forum-header">
        <h1>Welcome to the Forum</h1>
        <p>Engage in discussions, ask questions, and share knowledge.</p>
      </header>

      <section className="forum-actions">
        <button className="action-button">Post a Question</button>
        <button className="action-button">Browse Topics</button>
      </section>

      <section className="forum-feed">
        <h2>Recent Threads</h2>
        <ul className="thread-list">
          <li className="thread-item">
            <h3>How does React handle state updates?</h3>
            <p>Started by Alice · 5 replies · 12 upvotes</p>
          </li>
          <li className="thread-item">
            <h3>Best practices for Node.js backend development?</h3>
            <p>Started by Bob · 3 replies · 8 upvotes</p>
          </li>
        </ul>
      </section>
    </div>
  );
};

export default Home;
