import { useState } from 'react';

function Auth({ onLogin }) {
  const [isLogin, setIsLogin] = useState(true); // Toggle between login and sign-up
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    // Hardcoded login credentials (replace with backend logic later)
    if (username === 'user' && password === 'pass123') {
      onLogin({ username });
      setError('');
    } else {
      setError('Invalid username or password');
    }
  };

  const handleSignUpSubmit = (e) => {
    e.preventDefault();
    // Basic sign-up validation
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (username.trim() === '' || password.trim() === '') {
      setError('Username and password are required');
      return;
    }
    // Simulate successful sign-up (replace with backend logic later)
    // For now, we'll allow the user to sign up with any username/password
    onLogin({ username });
    setError('');
  };

  const toggleForm = () => {
    setIsLogin(!isLogin);
    setUsername('');
    setPassword('');
    setConfirmPassword('');
    setError('');
  };

  return (
    <div className="login-container">
      <h2>{isLogin ? 'Login to Forum' : 'Sign Up for Forum'}</h2>
      <form onSubmit={isLogin ? handleLoginSubmit : handleSignUpSubmit} className="login-form">
        <div className="form-group">
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder={isLogin ? 'Enter username (hint: user)' : 'Choose a username'}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder={isLogin ? 'Enter password (hint: pass123)' : 'Choose a password'}
            required
          />
        </div>
        {!isLogin && (
          <div className="form-group">
            <label htmlFor="confirm-password">Confirm Password:</label>
            <input
              type="password"
              id="confirm-password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm your password"
              required
            />
          </div>
        )}
        {error && <p className="error-message">{error}</p>}
        <button type="submit" className="action-button">
          {isLogin ? 'Login' : 'Sign Up'}
        </button>
      </form>
      <p className="toggle-form-text">
        {isLogin ? "Don't have an account?" : 'Already have an account?'}{' '}
        <button type="button" onClick={toggleForm} className="toggle-form-button">
          {isLogin ? 'Sign Up' : 'Login'}
        </button>
      </p>
    </div>
  );
}

export default Auth;